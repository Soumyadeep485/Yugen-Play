import 'package:flutter/foundation.dart';

import '../models/stream_link.dart';

/// Controls media playback state.
///
/// This controller is responsible for:
///
/// - Play / pause state
/// - Current stream
/// - Playback position
/// - Buffering state
///
/// The actual playback engine (media_kit)
/// will be connected later.
///
/// PlayerController decides WHAT to play.
/// PlaybackController decides HOW it plays.
class PlaybackController extends ChangeNotifier {
  StreamLink? _currentStream;

  bool _isPlaying = false;

  bool _isBuffering = false;

  Duration _position = Duration.zero;

  Duration _duration = Duration.zero;

  double _volume = 1.0;

  /// Currently loaded stream.
  StreamLink? get currentStream => _currentStream;

  /// Whether playback is active.
  bool get isPlaying => _isPlaying;

  /// Whether player is buffering.
  bool get isBuffering => _isBuffering;

  /// Current playback position.
  Duration get position => _position;

  /// Total media duration.
  Duration get duration => _duration;

  /// Current volume.
  double get volume => _volume;

  /// Loads a stream into the player.
  ///
  /// Actual initialization will be handled
  /// by media_kit later.
  Future<void> load(StreamLink stream) async {
    _currentStream = stream;

    _position = Duration.zero;

    _duration = Duration.zero;

    _isPlaying = false;

    notifyListeners();
  }

  /// Starts playback.
  Future<void> play() async {
    if (_currentStream == null) {
      return;
    }

    _isPlaying = true;

    notifyListeners();
  }

  /// Pauses playback.
  Future<void> pause() async {
    _isPlaying = false;

    notifyListeners();
  }

  /// Toggles play/pause.
  Future<void> toggle() async {
    if (_isPlaying) {
      await pause();
    } else {
      await play();
    }
  }

  /// Stops playback.
  Future<void> stop() async {
    _isPlaying = false;

    _position = Duration.zero;

    notifyListeners();
  }

  /// Seeks to a position.
  Future<void> seek(Duration position) async {
    _position = position;

    notifyListeners();
  }

  /// Updates buffering state.
  void setBuffering(bool buffering) {
    if (_isBuffering == buffering) {
      return;
    }

    _isBuffering = buffering;

    notifyListeners();
  }

  /// Updates duration.
  void setDuration(Duration duration) {
    _duration = duration;

    notifyListeners();
  }

  /// Updates playback position.
  void setPosition(Duration position) {
    _position = position;

    notifyListeners();
  }

  /// Changes volume.
  Future<void> setVolume(double value) async {
    _volume = value.clamp(0.0, 1.0);

    notifyListeners();
  }

  /// Releases resources.
  ///
  /// Media engine cleanup will be added
  /// when media_kit is integrated.
  @override
  void dispose() {
    _currentStream = null;

    super.dispose();
  }
}
