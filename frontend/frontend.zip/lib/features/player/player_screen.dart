import 'package:flutter/material.dart';

import '../../core/colors/app_colors.dart';
import '../../core/spacing/app_spacing.dart';
import 'controllers/player_controller.dart';
import 'widgets/audio_selector_sheet.dart';
import 'widgets/episode_selector_sheet.dart';
import 'widgets/player_controls.dart';
import 'widgets/player_info_section.dart';
import 'widgets/player_video_surface.dart';
import 'widgets/quality_selector_sheet.dart';
import 'widgets/server_selector_sheet.dart';
import 'widgets/subtitle_selector_sheet.dart';

class PlayerScreen extends StatefulWidget {
  const PlayerScreen({
    super.key,
    required this.controller,
    required this.animeTitle,
  });

  final PlayerController controller;
  final String animeTitle;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  PlayerController get _controller => widget.controller;

  @override
  void initState() {
    super.initState();

    _controller.addListener(_refresh);
  }

  @override
  void dispose() {
    _controller.removeListener(_refresh);

    super.dispose();
  }

  void _refresh() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.textPrimary,
        title: Text(
          'Player',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_controller.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_controller.hasError) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: Text(
            _controller.errorMessage ?? 'Something went wrong',
            textAlign: TextAlign.center,
            style: Theme.of(
              context,
            ).textTheme.bodyLarge?.copyWith(color: AppColors.error),
          ),
        ),
      );
    }

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: AppSpacing.md),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: PlayerVideoSurface(
              message: _controller.selectedStream == null
                  ? 'Select an episode and stream to begin.'
                  : 'Ready to play',
            ),
          ),

          PlayerInfoSection(
            animeTitle: widget.animeTitle,
            episode: _controller.selectedEpisode,
          ),

          PlayerControls(
            isPlayEnabled:
                _controller.selectedEpisode != null &&
                _controller.selectedServer != null &&
                _controller.selectedStream != null,
            onPlayPressed: () {
              // Playback engine in Phase 4.1D
            },
            onEpisodesPressed: _showEpisodeSelector,
            onServersPressed: _showServerSelector,
            onQualityPressed: _showQualitySelector,
            onSubtitlesPressed: _showSubtitleSelector,
            onAudioPressed: _showAudioSelector,
          ),

          const SizedBox(height: AppSpacing.xxl),
        ],
      ),
    );
  }

  void _showEpisodeSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      isScrollControlled: true,
      builder: (_) {
        return EpisodeSelectorSheet(
          episodes: _controller.episodes,
          selectedEpisode: _controller.selectedEpisode,
          onEpisodeSelected: (episode) {
            _controller.selectEpisode(episode);
          },
        );
      },
    );
  }

  void _showServerSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) {
        return ServerSelectorSheet(
          servers: _controller.servers,
          selectedServer: _controller.selectedServer,
          onServerSelected: (server) {
            _controller.selectServer(server);
          },
        );
      },
    );
  }

  void _showQualitySelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) {
        return QualitySelectorSheet(
          streamLinks: _controller.streamLinks,
          selectedStream: _controller.selectedStream,
          onQualitySelected: (stream) {
            _controller.selectStream(stream);
          },
        );
      },
    );
  }

  void _showSubtitleSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) {
        return SubtitleSelectorSheet(
          subtitles: _controller.subtitleTracks,
          selectedSubtitle: _controller.selectedSubtitle,
          onSubtitleSelected: (subtitle) {
            _controller.selectSubtitle(subtitle);
          },
        );
      },
    );
  }

  void _showAudioSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surface,
      builder: (_) {
        return AudioSelectorSheet(
          audioTracks: _controller.audioTracks,
          selectedAudio: _controller.selectedAudio,
          onAudioSelected: (audio) {
            _controller.selectAudio(audio);
          },
        );
      },
    );
  }
}
