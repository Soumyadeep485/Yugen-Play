import 'package:flutter/material.dart';

import '../../../core/colors/app_colors.dart';
import '../../../core/radius/app_radius.dart';
import '../../../core/spacing/app_spacing.dart';

/// Surface that hosts video playback.
///
/// Currently this widget displays a placeholder.
/// In a later phase, MediaKit will be embedded inside this
/// widget without changing its public API.
class PlayerVideoSurface extends StatelessWidget {
  const PlayerVideoSurface({
    super.key,
    this.providerName,
    this.message = 'No stream selected',
    this.onTap,
  });

  /// Name of the active provider.
  final String? providerName;

  /// Placeholder message.
  final String message;

  /// Called when the surface is tapped.
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return AspectRatio(
      aspectRatio: 16 / 9,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(AppRadius.lg),
          child: Ink(
            decoration: BoxDecoration(
              color: Colors.black,
              borderRadius: BorderRadius.circular(AppRadius.lg),
              border: Border.all(color: AppColors.card),
            ),
            child: Stack(
              fit: StackFit.expand,
              children: [
                // Future MediaKit player will replace this.
                const SizedBox.expand(),

                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(AppSpacing.lg),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.play_circle_fill_rounded,
                          size: 72,
                          color: Colors.white.withValues(alpha: 0.25),
                        ),

                        const SizedBox(height: AppSpacing.lg),

                        Text(
                          message,
                          textAlign: TextAlign.center,
                          style: textTheme.titleMedium?.copyWith(
                            color: AppColors.textPrimary,
                            fontWeight: FontWeight.w600,
                          ),
                        ),

                        if (providerName != null) ...[
                          const SizedBox(height: AppSpacing.sm),
                          Text(
                            providerName!,
                            textAlign: TextAlign.center,
                            style: textTheme.bodyMedium?.copyWith(
                              color: AppColors.textSecondary,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
