class DetailsQueries {
  DetailsQueries._();

  static const String animeDetails = r'''
query AnimeDetails($id: Int) {

  Media(id: $id, type: ANIME) {

    id

    title {
      english
      romaji
      native
    }

    coverImage {
      extraLarge
    }

    bannerImage

    description(asHtml:false)

    genres

    averageScore

    episodes

    duration

    format

    status

    season

    seasonYear

    source

    favourites

    popularity

    studios(isMain:true) {
      nodes {
        name
      }
    }
  }
}
''';
}
