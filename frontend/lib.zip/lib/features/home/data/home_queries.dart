class HomeQueries {
  HomeQueries._();

  static const String homeSection = r'''
query HomeSection($sort: [MediaSort], $status: MediaStatus) {

  Page(page: 1, perPage: 15) {

    media(
      type: ANIME
      sort: $sort
      status: $status
    ) {

      id

      title {
        english
        romaji
      }

      coverImage {
        extraLarge
      }

      genres

      averageScore

      episodes

      format
    }
  }
}
''';
}
