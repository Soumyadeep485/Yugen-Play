import 'package:graphql_flutter/graphql_flutter.dart';

import '../../../core/network/graphql_client.dart';
import '../../../shared/models/anime.dart';
import '../../../shared/models/home_data.dart';

import 'home_queries.dart';

class HomeRepository {
  Future<HomeData> getHomeData() async {
    final result = await GraphQLService.client.query(
      QueryOptions(
        document: gql(HomeQueries.homeFeed),
        fetchPolicy: FetchPolicy.networkOnly,
      ),
    );

    if (result.hasException) {
      throw Exception(result.exception.toString());
    }

    List<Anime> parse(dynamic page) {
      final media = page['media'] as List<dynamic>;

      return media
          .whereType<Map<String, dynamic>>()
          .map(Anime.fromAniListJson)
          .toList();
    }

    final trending = parse(result.data!['trending']);
    final popular = parse(result.data!['popular']);
    final airing = parse(result.data!['airing']);
    final upcoming = parse(result.data!['upcoming']);

    return HomeData(
      featuredAnime: trending.first,
      mostPopularAnime: popular,
      topRatedAnime: trending,
      currentlyAiringAnime: airing,
      upcomingAnime: upcoming,
    );
  }
}
