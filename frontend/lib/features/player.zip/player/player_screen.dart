import 'package:flutter/material.dart';

import '../../core/colors/app_colors.dart';
import '../../core/spacing/app_spacing.dart';
import 'controllers/player_controller.dart';
import 'widgets/player_controls.dart';
import 'widgets/player_info_section.dart';
import 'widgets/player_video_surface.dart';

/// Main player screen.
///
/// This is the composition layer of the player feature.
///
/// Responsibilities:
/// - Display player UI
/// - React to controller state
/// - Connect reusable player widgets
///
/// Playback logic remains outside this screen.
class PlayerScreen extends StatefulWidget {
  const PlayerScreen({
    super.key,
    required this.controller,
    required this.animeTitle,
  });

  final PlayerController controller;

  final String animeTitle;

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  PlayerController get _controller => widget.controller;

  @override
  void initState() {
    super.initState();

    _controller.addListener(_onControllerChanged);
  }

  @override
  void dispose() {
    _controller.removeListener(_onControllerChanged);

    super.dispose();
  }

  void _onControllerChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.textPrimary,
        title: Text(
          'Player',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
            color: AppColors.textPrimary,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
      body: _buildBody(context),
    );
  }

  Widget _buildBody(BuildContext context) {
    if (_controller.isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_controller.hasError) {
      return _buildErrorState();
    }

    return _buildPlayerContent();
  }

  Widget _buildPlayerContent() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: AppSpacing.md),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpacing.lg),
            child: PlayerVideoSurface(providerName: null),
          ),

          const SizedBox(height: AppSpacing.md),

          PlayerInfoSection(
            animeTitle: widget.animeTitle,
            episode: _controller.selectedEpisode,
          ),

          PlayerControls(
            isPlayEnabled: _controller.selectedStream != null,
            onPlayPressed: () {
              // Playback engine will be connected in Phase 4.1D.
            },
            onEpisodesPressed: () {
              // Added in Commit 2.
            },
            onServersPressed: () {
              // Added in Commit 2.
            },
            onQualityPressed: () {
              // Added in Commit 2.
            },
            onSubtitlesPressed: () {
              // Added in Commit 2.
            },
            onAudioPressed: () {
              // Added in Commit 2.
            },
          ),

          const SizedBox(height: AppSpacing.xxl),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppSpacing.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline_rounded,
              color: AppColors.error,
              size: 56,
            ),

            const SizedBox(height: AppSpacing.md),

            Text(
              _controller.errorMessage ?? 'Something went wrong',
              textAlign: TextAlign.center,
              style: Theme.of(
                context,
              ).textTheme.bodyLarge?.copyWith(color: AppColors.textPrimary),
            ),
          ],
        ),
      ),
    );
  }
}
